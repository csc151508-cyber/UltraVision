import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header.tsx';
import { Hero } from './components/Hero.tsx';
import { UploadZone } from './components/UploadZone.tsx';
import { VideoAnalysisCard } from './components/VideoAnalysisCard.tsx';
import { ProcessingView } from './components/ProcessingView.tsx';
import { ResultComparisonView } from './components/ResultComparisonView.tsx';
import { HowItWorks } from './components/HowItWorks.tsx';
import { FeaturesGrid } from './components/FeaturesGrid.tsx';
import { InteractiveShowcase } from './components/InteractiveShowcase.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { Footer } from './components/Footer.tsx';
import { AdminModal } from './components/AdminModal.tsx';
import { PrivacyTermsModal } from './components/PrivacyTermsModal.tsx';
import { ContactModal } from './components/ContactModal.tsx';

import type { 
  VideoJob, 
  VideoMetadata, 
  VideoAnalysis, 
  EnhanceOptions, 
  SampleVideo 
} from './types/index.ts';

type AppFlowState = 'upload' | 'analysis' | 'processing' | 'result';

export default function App() {
  const [flowState, setFlowState] = useState<AppFlowState>('upload');
  const [jobToken, setJobToken] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [analysis, setAnalysis] = useState<VideoAnalysis | null>(null);
  const [originalUrl, setOriginalUrl] = useState<string | undefined>(undefined);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | undefined>(undefined);

  // Upload state
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Processing state
  const [processingStatus, setProcessingStatus] = useState<string>('queued');
  const [processingProgress, setProcessingProgress] = useState<number>(0);
  const [processingStage, setProcessingStage] = useState<string>('');
  const [currentFrame, setCurrentFrame] = useState<number | undefined>(undefined);
  const [totalFrames, setTotalFrames] = useState<number | undefined>(undefined);
  const [etaSeconds, setEtaSeconds] = useState<number | undefined>(undefined);
  const [processingError, setProcessingError] = useState<string | undefined>(undefined);

  // Result state
  const [resultData, setResultData] = useState<any>(null);

  // Sample videos
  const [samples, setSamples] = useState<SampleVideo[]>([]);

  // Modals
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [legalModalType, setLegalModalType] = useState<'privacy' | 'terms' | null>(null);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);

  // Starting job loading state
  const [isStartingEnhance, setIsStartingEnhance] = useState<boolean>(false);

  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch sample videos on mount
  useEffect(() => {
    fetch('/api/sample-videos')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.samples) {
          setSamples(data.samples);
        }
      })
      .catch((err) => console.error('Failed to load samples', err));
  }, []);

  // Handle uploading user file
  const handleFileSelected = async (file: File) => {
    setIsUploading(true);
    setUploadProgress(15);
    setUploadError(null);

    const formData = new FormData();
    formData.append('video', file);

    try {
      setUploadProgress(45);
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      setUploadProgress(85);

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to upload video');
      }

      setUploadProgress(100);
      setJobToken(data.jobToken);
      setMetadata(data.metadata);
      setAnalysis(data.analysis);
      setOriginalUrl(data.originalUrl);
      setThumbnailUrl(data.thumbnailUrl);
      setFlowState('analysis');

      window.scrollTo({ top: 320, behavior: 'smooth' });
    } catch (err: any) {
      setUploadError(err.message || 'Error uploading file');
    } finally {
      setIsUploading(false);
    }
  };

  // Handle selecting a pre-loaded sample clip
  const handleSampleSelected = async (sampleId: string) => {
    setIsUploading(true);
    setUploadProgress(30);
    setUploadError(null);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sampleId }),
      });
      setUploadProgress(80);

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to initialize sample video');
      }

      setUploadProgress(100);
      setJobToken(data.jobToken);
      setMetadata(data.metadata);
      setAnalysis(data.analysis);
      setOriginalUrl(data.originalUrl);
      setThumbnailUrl(data.thumbnailUrl);
      setFlowState('analysis');

      window.scrollTo({ top: 320, behavior: 'smooth' });
    } catch (err: any) {
      setUploadError(err.message || 'Error initializing sample');
    } finally {
      setIsUploading(false);
    }
  };

  // Trigger enhancement pipeline
  const handleEnhance = async (options: EnhanceOptions) => {
    if (!jobToken) return;
    setIsStartingEnhance(true);
    setProcessingError(undefined);

    try {
      const res = await fetch('/api/enhance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobToken,
          mode: options.mode,
          targetResolution: options.targetResolution,
          denoiseStrength: options.denoiseStrength,
          faceRestoration: options.faceRestoration,
          audioPreservation: options.audioPreservation,
        }),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to start enhancement job');
      }

      setFlowState('processing');
      setProcessingStatus('queued');
      setProcessingProgress(5);
      setProcessingStage('Job registered in AI worker pipeline...');
      window.scrollTo({ top: 300, behavior: 'smooth' });

      startPollingStatus(jobToken);
    } catch (err: any) {
      setProcessingError(err.message || 'Failed to start job');
    } finally {
      setIsStartingEnhance(false);
    }
  };

  // Poll status endpoint
  const startPollingStatus = (token: string) => {
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);

    pollIntervalRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/status/${token}`);
        const data = await res.json();

        if (!data.success) {
          throw new Error(data.error || 'Status check failed');
        }

        setProcessingStatus(data.status);
        setProcessingProgress(data.progress);
        setProcessingStage(data.stage);
        setCurrentFrame(data.currentFrame);
        setTotalFrames(data.totalFrames);
        setEtaSeconds(data.etaSeconds);

        if (data.status === 'completed') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          fetchFinalResult(token);
        } else if (data.status === 'failed') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setProcessingError(data.error || 'Processing encountered an error.');
        } else if (data.status === 'cancelled') {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setFlowState('upload');
        }
      } catch (err) {
        console.error('Error polling status:', err);
      }
    }, 1500);
  };

  // Fetch final result
  const fetchFinalResult = async (token: string) => {
    try {
      const res = await fetch(`/api/result/${token}`);
      const data = await res.json();
      if (data.success) {
        setResultData(data);
        setFlowState('result');
        window.scrollTo({ top: 200, behavior: 'smooth' });
      }
    } catch (err) {
      console.error('Failed to fetch result', err);
    }
  };

  // Cancel processing
  const handleCancelProcessing = async () => {
    if (jobToken) {
      fetch(`/api/cancel/${jobToken}`, { method: 'POST' }).catch(() => {});
    }
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    handleReset();
  };

  // Reset all to clean upload state
  const handleReset = () => {
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    setFlowState('upload');
    setJobToken(null);
    setMetadata(null);
    setAnalysis(null);
    setOriginalUrl(undefined);
    setThumbnailUrl(undefined);
    setProcessingProgress(0);
    setResultData(null);
    setProcessingError(undefined);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0b0f17] text-slate-100">
      {/* Header */}
      <Header
        onOpenUpload={() => {
          if (flowState !== 'upload') handleReset();
          handleNavigate('upload-section');
        }}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onNavigate={handleNavigate}
      />

      <main className="flex-1">
        {/* State 1: Uploading & Home Landing View */}
        {flowState === 'upload' && (
          <>
            <Hero
              onScrollToUpload={() => handleNavigate('upload-section')}
              onTrySample={handleSampleSelected}
            />

            <UploadZone
              onFileSelected={handleFileSelected}
              onSampleSelected={handleSampleSelected}
              isUploading={isUploading}
              uploadProgress={uploadProgress}
              samples={samples}
            />

            <InteractiveShowcase />
            <FeaturesGrid />
            <HowItWorks />
            <FaqSection />
          </>
        )}

        {/* State 2: Video Analysis & Settings */}
        {flowState === 'analysis' && metadata && analysis && (
          <VideoAnalysisCard
            metadata={metadata}
            analysis={analysis}
            originalUrl={originalUrl}
            thumbnailUrl={thumbnailUrl}
            onEnhance={handleEnhance}
            onReset={handleReset}
            isStarting={isStartingEnhance}
          />
        )}

        {/* State 3: Real-Time Processing */}
        {flowState === 'processing' && (
          <ProcessingView
            progress={processingProgress}
            stage={processingStage}
            currentFrame={currentFrame}
            totalFrames={totalFrames}
            etaSeconds={etaSeconds}
            status={processingStatus}
            onCancel={handleCancelProcessing}
            error={processingError}
            adsEnabled={true}
          />
        )}

        {/* State 4: Before / After Result & Download */}
        {flowState === 'result' && resultData && (
          <ResultComparisonView
            result={resultData}
            onReset={handleReset}
            adsEnabled={true}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenPrivacy={() => setLegalModalType('privacy')}
        onOpenTerms={() => setLegalModalType('terms')}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Modals */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
      />

      <PrivacyTermsModal
        isOpen={legalModalType !== null}
        onClose={() => setLegalModalType(null)}
        type={legalModalType || 'privacy'}
      />

      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />
    </div>
  );
}
