export type EnhancementMode = 'auto' | 'quality_boost' | 'face_enhance' | 'ultra_hd';
export type OutputResolution = 'original' | '720p' | '1080p' | '1440p' | '4k';

export type JobStatus = 
  | 'uploaded'
  | 'analyzing'
  | 'queued'
  | 'processing'
  | 'finalizing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface VideoMetadata {
  filename: string;
  filesize: number;
  duration: number; // in seconds
  width: number;
  height: number;
  fps: number;
  codec: string;
  audioCodec?: string;
  hasAudio: boolean;
  bitrateKbps: number;
}

export interface VideoAnalysis {
  resolutionLabel: string;
  fps: number;
  noiseLevel: 'Low' | 'Medium' | 'High';
  compressionArtifacts: 'Minimal' | 'Moderate' | 'Heavy';
  detailClarity: 'Crisp' | 'Soft' | 'Degraded';
  faceDetected: boolean;
  recommendedMode: EnhancementMode;
  recommendedResolution: OutputResolution;
  estimatedProcessingSeconds: number;
}

export interface EnhanceOptions {
  mode: EnhancementMode;
  targetResolution: OutputResolution;
  denoiseStrength: number; // 0-100
  faceRestoration: boolean;
  audioPreservation: boolean;
}

export interface VideoJob {
  jobToken: string;
  createdAt: number;
  status: JobStatus;
  progress: number; // 0 - 100
  currentStage: string;
  currentFrame?: number;
  totalFrames?: number;
  etaSeconds?: number;
  metadata: VideoMetadata;
  analysis?: VideoAnalysis;
  options?: EnhanceOptions;
  originalUrl?: string;
  enhancedUrl?: string;
  thumbnailUrl?: string;
  downloadToken?: string;
  outputSize?: number;
  outputWidth?: number;
  outputHeight?: number;
  error?: string;
}

export interface AdminStats {
  totalJobs: number;
  todayJobs: number;
  processingJobs: number;
  completedJobs: number;
  failedJobs: number;
  totalStorageMB: number;
  totalDataProcessedGB: number;
  averageProcessingTimeSec: number;
  workerStatus: 'ONLINE' | 'STANDBY' | 'BUSY';
  gpuUtilization: number;
  vramUsageGB: number;
  vramTotalGB: number;
}

export interface SystemSettings {
  maxUploadSizeMB: number;
  maxDurationSec: number;
  allowedExtensions: string[];
  retentionHours: number;
  adsEnabled: boolean;
  maintenanceMode: boolean;
  siteName: string;
  tagline: string;
}

export interface SampleVideo {
  id: string;
  title: string;
  description: string;
  duration: string;
  resolution: string;
  previewUrl: string;
  originalThumbnail: string;
  enhancedThumbnail: string;
}
