import React from 'react';
import { 
  Sparkles, 
  Maximize2, 
  ShieldCheck, 
  Volume2, 
  Eye, 
  Activity,
  Layers,
  Zap
} from 'lucide-react';

export const FeaturesGrid: React.FC = () => {
  return (
    <section id="features" className="py-20 border-b border-slate-800/60 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-400 mb-2 uppercase tracking-wider">
            <span>Core Capabilities</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Technology</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display mb-4">
            Engineered for Flawless Restoration
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            UltraVision AI uses modular deep neural models and hardware-accelerated transcoding pipelines to enhance every frame.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Super Resolution (col-span-2) */}
          <div className="md:col-span-2 p-8 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-6">
              <Maximize2 className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-display">
              Sub-Pixel Super-Resolution (Up to 4K)
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xl mb-4">
              Restores missing high-frequency details rather than merely stretching pixels. Our neural algorithm calculates contextual edge trajectories across consecutive frames to synthesize sharp, natural contours.
            </p>
            <div className="flex items-center gap-3 text-xs text-blue-300 font-mono">
              <span>720p HD</span>
              <span>→</span>
              <span>1080p FHD</span>
              <span>→</span>
              <span>1440p 2K</span>
              <span>→</span>
              <span>4K UHD</span>
            </div>
          </div>

          {/* Card 2: Facial Restoration */}
          <div className="p-8 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-purple-600/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-6">
              <Eye className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-display">
              Neural Face Restoration
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Detects human facial landmarks and recovers clear pupils, eyelashes, skin micro-texture, and expressions without artificial waxiness.
            </p>
          </div>

          {/* Card 3: Artifact & Noise De-blocking */}
          <div className="p-8 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-6">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-display">
              Macroblock De-compression
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Eliminates heavy compression artifacts, pixelated mosquito noise, and banding from social media or old camera footage.
            </p>
          </div>

          {/* Card 4: Audio Preservation (col-span-2) */}
          <div className="md:col-span-2 p-8 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 transition-colors">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-6">
              <Volume2 className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-display">
              Lossless Audio Track Preservation
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xl mb-4">
              Unlike primitive upscalers that strip or corrupt audio tracks, UltraVision AI separates and synchronizes original stereo/surround streams, multiplexing them back into the final high-definition MP4.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono">
              <ShieldCheck className="w-4 h-4" />
              <span>Full AV Sync · AAC 192kbps or Direct Stream Copy</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
