import React from 'react';
import { Sparkles, SlidersHorizontal, ShieldCheck } from 'lucide-react';

interface HeaderProps {
  onOpenUpload: () => void;
  onOpenAdmin: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenUpload, onOpenAdmin, onNavigate }) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#0b0f17]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className="flex items-center gap-2 group text-white font-semibold text-lg tracking-tight"
        >
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:border-blue-400 transition-colors">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="font-display tracking-tight text-white group-hover:text-blue-300 transition-colors">
            UltraVision AI
          </span>
        </a>

        {/* Zone 2: 4-5 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
          <button 
            onClick={() => onNavigate('upload-section')} 
            className="hover:text-slate-100 transition-colors cursor-pointer"
          >
            Enhance
          </button>
          <button 
            onClick={() => onNavigate('how-it-works')} 
            className="hover:text-slate-100 transition-colors cursor-pointer"
          >
            How It Works
          </button>
          <button 
            onClick={() => onNavigate('features')} 
            className="hover:text-slate-100 transition-colors cursor-pointer"
          >
            Capabilities
          </button>
          <button 
            onClick={() => onNavigate('showcase')} 
            className="hover:text-slate-100 transition-colors cursor-pointer"
          >
            Comparison
          </button>
          <button 
            onClick={() => onNavigate('faq')} 
            className="hover:text-slate-100 transition-colors cursor-pointer"
          >
            FAQ
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAdmin}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-md transition-colors border border-transparent hover:border-slate-700/60"
            title="System Diagnostics & Admin Console"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>

          <button
            onClick={onOpenUpload}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg shadow-sm shadow-blue-500/20 transition-all duration-150 cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Upload Video</span>
          </button>
        </div>
      </div>
    </header>
  );
};
