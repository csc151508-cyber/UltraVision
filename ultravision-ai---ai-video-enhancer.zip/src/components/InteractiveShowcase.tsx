import React, { useState, useRef } from 'react';
import { Sparkles, SlidersHorizontal, ArrowRight } from 'lucide-react';

interface ShowcaseItem {
  id: string;
  title: string;
  category: string;
  resolutionBefore: string;
  resolutionAfter: string;
  image: string;
  blurBefore: boolean;
  description: string;
}

export const InteractiveShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [sliderPos, setSliderPos] = useState<number>(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef<boolean>(false);

  const items: ShowcaseItem[] = [
    {
      id: 'cinematic',
      title: 'Cinematic 35mm Archival Restoration',
      category: 'Vintage Footage',
      resolutionBefore: '480p SD',
      resolutionAfter: '4K Remastered',
      image: '/src/assets/images/hero_cinematic_restoration_1790847192064.jpg',
      blurBefore: true,
      description: 'Removes deep analog grain and compression noise while sharpening optical edges and color fidelity.',
    },
    {
      id: 'face',
      title: 'Neural Facial & Micro-Detail Recovery',
      category: 'Portrait Video',
      resolutionBefore: '720p HD',
      resolutionAfter: '1440p 2K',
      image: '/src/assets/images/showcase_face_enhancement_1790847204986.jpg',
      blurBefore: true,
      description: 'Synthesizes authentic skin texture, realistic iris reflections, and eliminates pixelated facial compression.',
    },
    {
      id: 'landscape',
      title: 'High-Frequency Nature & Architecture',
      category: 'Landscape 4K',
      resolutionBefore: '720p HD',
      resolutionAfter: '4K UHD',
      image: '/src/assets/images/showcase_landscape_upscale_1790847215501.jpg',
      blurBefore: true,
      description: 'Reconstructs intricate pine needles, mountain ridges, and subtle light reflections across twilight water.',
    },
  ];

  const current = items[activeTab];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current || e.touches.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.touches[0].clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  };

  return (
    <section id="showcase" className="py-20 border-b border-slate-800/60 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-400 mb-2 uppercase tracking-wider">
            <span>Visual Evidence</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Before / After</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display mb-4">
            See the Neural Difference
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Drag the interactive slider below to inspect the transformation from degraded source input to crystal-clear output.
          </p>
        </div>

        {/* Category Tabs (Functional segmented buttons) */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 rounded-xl bg-slate-900 border border-slate-800">
            {items.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(idx);
                  setSliderPos(50);
                }}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === idx
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {item.category}
              </button>
            ))}
          </div>
        </div>

        {/* Interactive Split-Slider Card */}
        <div className="max-w-4xl mx-auto rounded-2xl overflow-hidden border border-slate-800 bg-black shadow-2xl relative">
          <div
            ref={containerRef}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative aspect-video w-full cursor-ew-resize select-none overflow-hidden"
          >
            {/* Enhanced Image (Background - Sharp) */}
            <img
              src={current.image}
              alt="Enhanced sample preview"
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              referrerPolicy="no-referrer"
            />

            {/* Original Image (Overlay - Blurred/Grainy to emulate low-res) */}
            <div
              className="absolute inset-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPos}%` }}
            >
              <img
                src={current.image}
                alt="Original sample preview"
                className="absolute inset-0 w-full h-full object-cover filter blur-[3px] contrast-85 brightness-90 saturate-75"
                style={{
                  width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%',
                  maxWidth: 'none',
                }}
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Split Handle */}
            <div
              onMouseDown={() => { isDraggingRef.current = true; }}
              className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 shadow-[0_0_15px_rgba(0,0,0,0.9)]"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-white text-slate-900 shadow-xl flex items-center justify-center font-bold text-xs pointer-events-auto cursor-grab active:cursor-grabbing border border-slate-300">
                ⇄
              </div>
            </div>

            {/* Labels */}
            <div className="absolute top-4 left-4 z-10 px-3 py-1 rounded bg-black/80 backdrop-blur-sm border border-white/10 text-xs font-semibold text-slate-300">
              ORIGINAL ({current.resolutionBefore})
            </div>
            <div className="absolute top-4 right-4 z-10 px-3 py-1 rounded bg-blue-600/90 backdrop-blur-sm border border-blue-400/30 text-xs font-semibold text-white">
              AI RESTORED ({current.resolutionAfter})
            </div>
          </div>

          {/* Card Footer */}
          <div className="p-5 bg-slate-900/90 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-semibold text-white font-display">
                {current.title}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {current.description}
              </p>
            </div>
            <div className="text-xs font-mono text-slate-400 shrink-0">
              Drag slider to compare detail
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
