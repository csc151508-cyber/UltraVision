import React, { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { UploadCloud, Film, AlertCircle, Sparkles, CheckCircle2, Play } from 'lucide-react';
import type { SampleVideo } from '../types/index.ts';

interface UploadZoneProps {
  onFileSelected: (file: File) => void;
  onSampleSelected: (sampleId: string) => void;
  isUploading: boolean;
  uploadProgress: number;
  samples: SampleVideo[];
  maxSizeMB?: number;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  onFileSelected,
  onSampleSelected,
  isUploading,
  uploadProgress,
  samples,
  maxSizeMB = 500,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [clientError, setClientError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateAndSubmit = (file: File) => {
    setClientError(null);

    // Validate size
    const maxBytes = maxSizeMB * 1024 * 1024;
    if (file.size > maxBytes) {
      setClientError(`Video exceeds the maximum size limit of ${maxSizeMB} MB. Please select a smaller video.`);
      return;
    }

    // Validate format
    const validExtensions = /\.(mp4|mov|webm|mkv|avi)$/i;
    const validMimes = ['video/mp4', 'video/quicktime', 'video/webm', 'video/x-matroska', 'video/avi', 'video/x-msvideo'];

    if (!validExtensions.test(file.name) && !validMimes.includes(file.type)) {
      setClientError('Unsupported format. Please upload MP4, MOV, WEBM, MKV, or AVI.');
      return;
    }

    onFileSelected(file);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      validateAndSubmit(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      validateAndSubmit(e.target.files[0]);
    }
  };

  return (
    <div id="upload-section" className="w-full max-w-4xl mx-auto px-4 py-8">
      {/* Upload Box */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !isUploading && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center transition-all duration-200 cursor-pointer overflow-hidden ${
          isDragOver
            ? 'border-blue-500 bg-blue-950/20'
            : 'border-slate-700/80 bg-slate-900/50 hover:border-slate-600 hover:bg-slate-900/80'
        } ${isUploading ? 'pointer-events-none opacity-90' : ''}`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".mp4,.mov,.webm,.mkv,.avi,video/mp4,video/quicktime,video/webm,video/x-matroska,video/avi"
          onChange={handleFileInput}
          className="hidden"
        />

        {isUploading ? (
          <div className="py-6 max-w-md mx-auto">
            <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 mx-auto flex items-center justify-center mb-4">
              <UploadCloud className="w-6 h-6 animate-pulse" />
            </div>
            <h3 className="text-base font-semibold text-white mb-2">
              Uploading Video...
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Transferring file to secure local pipeline for neural analysis
            </p>
            {/* Progress bar */}
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden mb-2">
              <div
                className="bg-blue-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${Math.max(5, uploadProgress)}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-slate-500 font-mono">
              <span>Transferring</span>
              <span>{Math.round(uploadProgress)}%</span>
            </div>
          </div>
        ) : (
          <div>
            <div className="w-16 h-16 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 mx-auto flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
              <UploadCloud className="w-8 h-8" />
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white mb-2 font-display">
              Drag & Drop Your Video
            </h2>

            <p className="text-sm text-slate-400 mb-6 max-w-md mx-auto">
              Drop any video here or browse from your device. No sign-up required.
            </p>

            <div className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm shadow-blue-500/20 transition-colors mb-6">
              <Film className="w-4 h-4" />
              <span>Browse File</span>
            </div>

            {/* Formats and Limits */}
            <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs text-slate-400 font-medium">
              <span>MP4</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>MOV</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>WEBM</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>MKV</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>AVI</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Max {maxSizeMB} MB</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Up to 5 min</span>
            </div>
          </div>
        )}
      </div>

      {/* Error alert */}
      {clientError && (
        <div className="mt-4 p-4 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-sm flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <p>{clientError}</p>
        </div>
      )}

      {/* Sample Clips Picker */}
      <div className="mt-8 border-t border-slate-800/80 pt-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Don't have a video handy?</h3>
            <p className="text-xs text-slate-400">Click any pre-loaded test clip to preview enhancement instantly:</p>
          </div>
          <span className="text-xs text-slate-400">1-click test</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {samples.map((s) => (
            <button
              key={s.id}
              onClick={() => onSampleSelected(s.id)}
              disabled={isUploading}
              className="text-left p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-blue-500/50 hover:bg-slate-900/90 transition-all cursor-pointer group flex items-start gap-3 disabled:opacity-50"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-900/30 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <Play className="w-4 h-4 fill-blue-400" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-slate-200 group-hover:text-blue-300 transition-colors truncate">
                  {s.title}
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {s.description}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-1">
                  <span>{s.resolution}</span>
                  <span>·</span>
                  <span>{s.duration}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
