import React from 'react';
import { UploadCloud, SearchCheck, Cpu, Download } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Upload Footage',
      desc: 'Drag and drop any low-res or compressed MP4, MOV, WEBM, MKV, or AVI video. No account or credentials required.',
      icon: UploadCloud,
    },
    {
      num: '02',
      title: 'Neural Analysis',
      desc: 'Our engine inspects resolution, noise levels, compression artifacts, and facial geometry to configure the optimal restoration pipeline.',
      icon: SearchCheck,
    },
    {
      num: '03',
      title: 'AI Super-Resolution',
      desc: 'Multi-pass neural restoration reconstructs high-frequency edge detail, denoises dark areas, and upscales frames to 1080p or 4K.',
      icon: Cpu,
    },
    {
      num: '04',
      title: 'Instant Download',
      desc: 'Preview the restored footage side-by-side using the interactive comparison slider and export the pristine video with audio intact.',
      icon: Download,
    },
  ];

  return (
    <section id="how-it-works" className="py-20 border-b border-slate-800/60 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-400 mb-2 uppercase tracking-wider">
            <span>Automated Architecture</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>How It Works</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display mb-4">
            Four Steps to Cinematic Clarity
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            A frictionless workflow designed for instant video enhancement without sign-up hurdles or complex parameter tweaking.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {steps.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.num}
                className="p-6 rounded-2xl border border-slate-800 bg-slate-900/40 relative group hover:border-slate-700 hover:bg-slate-900/80 transition-all duration-200"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="font-mono text-xs font-semibold text-slate-400">
                    {s.num}
                  </span>
                </div>

                <h3 className="text-base font-semibold text-white mb-2 font-display">
                  {s.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {s.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
