import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FaqItem {
  q: string;
  a: string;
}

export const FaqSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      q: 'Do I need to create an account or sign in?',
      a: 'No. UltraVision AI operates completely registration-free. You simply upload your video, configure your preferred enhancement settings, and download your restored file without entering personal information or passwords.',
    },
    {
      q: 'What video formats and limits are supported?',
      a: 'We support MP4, MOV, WEBM, MKV, and AVI video formats up to 500 MB in file size and up to 5 minutes in duration per job. Uploaded streams are validated through media probes before processing.',
    },
    {
      q: 'Will the original audio track remain intact?',
      a: 'Yes. Our pipeline extracts and isolates the original audio stream prior to frame restoration, and re-multiplexes it with sample-accurate synchronization into the final enhanced MP4 container.',
    },
    {
      q: 'How long does the AI video enhancement take?',
      a: 'Processing duration depends on clip duration and target resolution. Most 10-second to 1-minute clips complete in approximately 10 to 30 seconds on our dedicated GPU pipeline.',
    },
    {
      q: 'Are my uploaded videos stored permanently?',
      a: 'No. All uploaded originals, intermediate extracted frames, and final enhanced outputs are automatically and permanently deleted from our servers within 6 hours of processing.',
    },
    {
      q: 'Can any low-quality video be upscaled to native 4K?',
      a: 'AI super-resolution synthesizes missing micro-textures and sharpens optical contours to provide a substantial perceptual clarity boost. However, we do not promise magical fabrication of details completely absent from the source footage.',
    },
  ];

  return (
    <section id="faq" className="py-20 border-b border-slate-800/60 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-400 mb-2 uppercase tracking-wider">
            <span>Clarifications</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Frequently Asked Questions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display mb-4">
            Answers & Technical Policies
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Everything you need to know about our video processing architecture and privacy guarantees.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-800 bg-slate-900/50 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-900/80 transition-colors"
                >
                  <span className="text-sm sm:text-base font-semibold text-white font-display">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-blue-400' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-400 leading-relaxed border-t border-slate-800/60 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
