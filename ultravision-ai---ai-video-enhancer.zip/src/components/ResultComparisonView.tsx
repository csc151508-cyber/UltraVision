import React, { useState, useRef, useEffect } from 'react';
import { 
  Download, 
  RotateCcw, 
  CheckCircle2, 
  Maximize2, 
  Columns, 
  Sparkles, 
  Volume2, 
  Play, 
  Pause,
  Sliders,
  ShieldCheck
} from 'lucide-react';

interface ResultData {
  jobToken: string;
  downloadToken?: string;
  original: {
    url?: string;
    width: number;
    height: number;
    fps: number;
    size: number;
    bitrateKbps: number;
    duration: number;
    codec: string;
  };
  enhanced: {
    url?: string;
    downloadUrl: string;
    width: number;
    height: number;
    fps: number;
    size: number;
    bitrateKbps: number;
    mode?: string;
    targetResolution?: string;
  };
}

interface ResultComparisonViewProps {
  result: ResultData;
  onReset: () => void;
  adsEnabled?: boolean;
}

export const ResultComparisonView: React.FC<ResultComparisonViewProps> = ({
  result,
  onReset,
  adsEnabled = true,
}) => {
  const [sliderPosition, setSliderPosition] = useState<number>(50); // 0 - 100%
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(result.original.duration || 10);
  const [viewMode, setViewMode] = useState<'slider' | 'side-by-side' | 'enhanced' | 'original'>('slider');

  const containerRef = useRef<HTMLDivElement>(null);
  const originalVideoRef = useRef<HTMLVideoElement>(null);
  const enhancedVideoRef = useRef<HTMLVideoElement>(null);
  const isDraggingRef = useRef<boolean>(false);

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${Math.round(bytes / 1024)} KB`;
  };

  // Sync playback between both videos
  const togglePlay = () => {
    const orig = originalVideoRef.current;
    const enh = enhancedVideoRef.current;
    if (!orig || !enh) return;

    if (orig.paused || enh.paused) {
      orig.play().catch(() => {});
      enh.play().catch(() => {});
      setIsPlaying(true);
    } else {
      orig.pause();
      enh.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    if (enhancedVideoRef.current) {
      setCurrentTime(enhancedVideoRef.current.currentTime);
      if (enhancedVideoRef.current.duration) {
        setDuration(enhancedVideoRef.current.duration);
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    setCurrentTime(time);
    if (originalVideoRef.current) originalVideoRef.current.currentTime = time;
    if (enhancedVideoRef.current) enhancedVideoRef.current.currentTime = time;
  };

  // Dragging split slider
  const handleMouseDown = () => {
    isDraggingRef.current = true;
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current || e.touches.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.touches[0].clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  useEffect(() => {
    window.addEventListener('mouseup', handleMouseUp);
    return () => window.removeEventListener('mouseup', handleMouseUp);
  }, []);

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>ENHANCEMENT COMPLETE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white font-display">
            Your Video Is Ready
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onReset}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors border border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Enhance Another</span>
          </button>

          <a
            href={result.enhanced.downloadUrl}
            download
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-lg shadow-blue-500/20 transition-all cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4" />
            <span>Download Enhanced Video</span>
          </a>
        </div>
      </div>

      {/* View Mode Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs font-medium">
          <button
            onClick={() => setViewMode('slider')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'slider' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Split Slider
          </button>
          <button
            onClick={() => setViewMode('side-by-side')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'side-by-side' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Side-by-Side
          </button>
          <button
            onClick={() => setViewMode('enhanced')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'enhanced' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Enhanced Only
          </button>
          <button
            onClick={() => setViewMode('original')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
              viewMode === 'original' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Original
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
            <span>Original ({result.original.width}×{result.original.height})</span>
          </span>
          <span className="text-slate-700">·</span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            <span className="text-blue-300 font-medium">AI Enhanced ({result.enhanced.width}×{result.enhanced.height})</span>
          </span>
        </div>
      </div>

      {/* Main Video Comparison Surface */}
      <div className="relative rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl mb-4">
        {viewMode === 'slider' && (
          <div
            ref={containerRef}
            onMouseMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative aspect-video w-full cursor-ew-resize select-none overflow-hidden"
          >
            {/* Enhanced Video (Background Layer) */}
            <video
              ref={enhancedVideoRef}
              src={result.enhanced.url}
              autoPlay
              loop
              muted
              playsInline
              onTimeUpdate={handleTimeUpdate}
              className="absolute inset-0 w-full h-full object-contain pointer-events-none"
            />

            {/* Original Video (Clipped Overlay Layer) */}
            <div
              className="absolute inset-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPosition}%` }}
            >
              <video
                ref={originalVideoRef}
                src={result.original.url}
                autoPlay
                loop
                muted
                playsInline
                className="absolute inset-0 w-full h-full object-contain"
                style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%', maxWidth: 'none' }}
              />
            </div>

            {/* Vertical Divider Line with Draggable Handle */}
            <div
              onMouseDown={handleMouseDown}
              className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-20 shadow-[0_0_12px_rgba(0,0,0,0.8)]"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white text-slate-900 shadow-lg flex items-center justify-center font-bold text-xs pointer-events-auto cursor-grab active:cursor-grabbing border border-slate-300">
                ⇄
              </div>
            </div>

            {/* Overlay Labels */}
            <div className="absolute top-4 left-4 z-10 px-2.5 py-1 rounded bg-black/75 backdrop-blur-sm border border-white/10 text-[11px] font-semibold text-slate-300">
              ORIGINAL ({result.original.height}p)
            </div>
            <div className="absolute top-4 right-4 z-10 px-2.5 py-1 rounded bg-blue-600/80 backdrop-blur-sm border border-blue-400/30 text-[11px] font-semibold text-white">
              AI ENHANCED ({result.enhanced.height}p)
            </div>
          </div>
        )}

        {viewMode === 'side-by-side' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-800">
            {/* Original Box */}
            <div className="relative aspect-video bg-black flex items-center justify-center">
              <video
                src={result.original.url}
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-contain"
              />
              <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/80 text-[11px] font-semibold text-slate-300">
                ORIGINAL ({result.original.width}×{result.original.height})
              </div>
            </div>

            {/* Enhanced Box */}
            <div className="relative aspect-video bg-black flex items-center justify-center">
              <video
                src={result.enhanced.url}
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-contain"
              />
              <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-blue-600/90 text-[11px] font-semibold text-white">
                ENHANCED ({result.enhanced.width}×{result.enhanced.height})
              </div>
            </div>
          </div>
        )}

        {viewMode === 'enhanced' && (
          <div className="relative aspect-video bg-black flex items-center justify-center">
            <video
              src={result.enhanced.url}
              controls
              autoPlay
              loop
              playsInline
              className="w-full h-full object-contain"
            />
            <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-blue-600/90 text-[11px] font-semibold text-white">
              AI ENHANCED ({result.enhanced.width}×{result.enhanced.height})
            </div>
          </div>
        )}

        {viewMode === 'original' && (
          <div className="relative aspect-video bg-black flex items-center justify-center">
            <video
              src={result.original.url}
              controls
              autoPlay
              loop
              playsInline
              className="w-full h-full object-contain"
            />
            <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/80 text-[11px] font-semibold text-slate-300">
              ORIGINAL ({result.original.width}×{result.original.height})
            </div>
          </div>
        )}

        {/* Video Scrubber & Play Bar */}
        <div className="p-3 bg-slate-900/95 border-t border-slate-800 flex items-center gap-4">
          <button
            onClick={togglePlay}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
          </button>

          <input
            type="range"
            min="0"
            max={duration || 10}
            step="0.05"
            value={currentTime}
            onChange={handleSeek}
            className="flex-1 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />

          <span className="text-xs font-mono text-slate-400 whitespace-nowrap">
            {Math.floor(currentTime)}s / {Math.floor(duration)}s
          </span>
        </div>
      </div>

      {/* Side-by-Side Comparison Metrics (Section 20 of Spec) */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 mb-8">
        <h3 className="text-sm font-semibold text-white uppercase tracking-wider mb-4 font-display">
          Restoration Quality Metrics
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-3 font-semibold">STREAM PARAMETER</th>
                <th className="pb-3 font-semibold">ORIGINAL SOURCE</th>
                <th className="pb-3 font-semibold text-blue-400">AI ENHANCED OUTPUT</th>
                <th className="pb-3 font-semibold text-right">NET IMPROVEMENT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-200">
              <tr>
                <td className="py-3 text-slate-400 font-sans">Resolution</td>
                <td className="py-3">{result.original.width} × {result.original.height}</td>
                <td className="py-3 text-blue-400 font-semibold">{result.enhanced.width} × {result.enhanced.height}</td>
                <td className="py-3 text-right text-emerald-400">
                  +{Math.round(((result.enhanced.width * result.enhanced.height) / (result.original.width * result.original.height) - 1) * 100)}% Pixels
                </td>
              </tr>
              <tr>
                <td className="py-3 text-slate-400 font-sans">Bitrate</td>
                <td className="py-3">{result.original.bitrateKbps.toLocaleString()} kbps</td>
                <td className="py-3 text-blue-400 font-semibold">{result.enhanced.bitrateKbps.toLocaleString()} kbps</td>
                <td className="py-3 text-right text-emerald-400">+{(result.enhanced.bitrateKbps / Math.max(1, result.original.bitrateKbps)).toFixed(1)}x Bandwidth</td>
              </tr>
              <tr>
                <td className="py-3 text-slate-400 font-sans">File Size</td>
                <td className="py-3">{formatFileSize(result.original.size)}</td>
                <td className="py-3 text-blue-400 font-semibold">{formatFileSize(result.enhanced.size)}</td>
                <td className="py-3 text-right text-slate-400">High-bitrate H.264</td>
              </tr>
              <tr>
                <td className="py-3 text-slate-400 font-sans">Audio Fidelity</td>
                <td className="py-3">{result.original.codec} (Original)</td>
                <td className="py-3 text-emerald-400 font-semibold">AAC 192 kbps (Preserved)</td>
                <td className="py-3 text-right text-emerald-400">Lossless Sync</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Download Action Section */}
      <div className="p-8 rounded-2xl border border-blue-900/40 bg-gradient-to-b from-blue-950/30 to-slate-900/60 text-center">
        <h3 className="text-xl font-bold text-white mb-2 font-display">
          Download Your Crystal-Clear Video
        </h3>
        <p className="text-sm text-slate-400 max-w-lg mx-auto mb-6">
          Your video has been rendered without watermarks. Download links are secured by temporary tokens and automatically purged in 6 hours.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <a
            href={result.enhanced.downloadUrl}
            download
            className="px-8 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-lg shadow-blue-500/25 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Enhanced Video ({result.enhanced.height}p)</span>
          </a>

          <button
            onClick={onReset}
            className="px-6 py-3.5 text-sm font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors cursor-pointer"
          >
            Enhance Another Video
          </button>
        </div>
      </div>

      {/* Section 19 Google Ad Slot on Result Page */}
      {adsEnabled && (
        <div className="mt-8 pt-6 border-t border-slate-800 text-center">
          <div className="text-[10px] tracking-widest text-slate-400 uppercase mb-2">
            Advertisement
          </div>
          <div className="w-full max-w-xl mx-auto h-20 rounded-xl border border-slate-800/80 bg-slate-950/60 flex flex-col items-center justify-center p-3 text-slate-500">
            <span className="text-xs font-medium text-slate-400">Google AdSense Placement</span>
            <span className="text-[11px] text-slate-400">Compliant sponsor partner placement · Never disguised as a download link</span>
          </div>
        </div>
      )}
    </div>
  );
};
