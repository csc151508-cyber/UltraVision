import React from 'react';
import { X, ShieldCheck, Lock, Trash2, Key } from 'lucide-react';

interface PrivacyTermsModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'privacy' | 'terms';
}

export const PrivacyTermsModal: React.FC<PrivacyTermsModalProps> = ({
  isOpen,
  onClose,
  type,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col bg-[#0d121c] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
            <h2 className="text-base font-bold text-white font-display">
              {type === 'privacy' ? 'Privacy Policy & Data Retention' : 'Terms of Service'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {type === 'privacy' ? (
            <>
              <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-800/40 text-blue-200 text-xs flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Strict Ephemeral Retention:</strong> Videos uploaded to UltraVision AI are processed in isolated memory/scratch space and automatically wiped after 6 hours. We never sell, index, or train public AI models on user videos.
                </span>
              </div>

              <h3 className="text-sm font-semibold text-white pt-2">1. No Account, No Registration</h3>
              <p>
                UltraVision AI is built with zero registration requirements. We do not ask for your name, email, phone number, or payment details for standard video enhancement.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">2. Cryptographic Session Isolation</h3>
              <p>
                Each uploaded video is assigned an unpredictable 128-bit cryptographically secure random token (e.g. <code>/download/8a4f9e...</code>). File downloads can only be accessed by the client possessing the unique token. Sequential ID enumeration is strictly prevented.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">3. Automated 6-Hour Storage Purge</h3>
              <p>
                Original uploads, temporary extracted video frames, intermediate tensors, and final enhanced outputs are queued for immediate deletion upon expiration. All artifacts are irreversibly deleted from our storage volumes within 6 hours.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">4. Zero Audio Harvesting</h3>
              <p>
                Audio tracks are preserved strictly for multiplexing into the user’s final enhanced MP4 file and are wiped synchronously with the video frames.
              </p>
            </>
          ) : (
            <>
              <h3 className="text-sm font-semibold text-white">1. Service Scope</h3>
              <p>
                UltraVision AI provides automated video restoration, denoising, and super-resolution upscaling. While our AI models deliver state-of-the-art visual recovery, results inherently depend on the resolution, lighting, and compression characteristics of the source video.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">2. Acceptable Use</h3>
              <p>
                Users agree not to upload content containing unlawful material, malware, or content that infringes upon third-party intellectual property rights. We reserve the right to abort automated processing of videos violating these policies.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">3. Ephemeral File Delivery</h3>
              <p>
                Because files are automatically deleted after 6 hours, users are responsible for downloading and archiving their enhanced videos promptly after processing completes.
              </p>

              <h3 className="text-sm font-semibold text-white pt-2">4. Disclaimer of Warranties</h3>
              <p>
                The platform is provided on an &quot;as is&quot; and &quot;as available&quot; basis. UltraVision AI disclaims all warranties regarding continuous uninterrupted availability or guaranteed fidelity levels for corrupted input files.
              </p>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
