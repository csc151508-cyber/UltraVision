import React from 'react';
import { Cpu, AlertCircle, X, Sparkles, CheckCircle2 } from 'lucide-react';

interface ProcessingViewProps {
  progress: number;
  stage: string;
  currentFrame?: number;
  totalFrames?: number;
  etaSeconds?: number;
  status: string;
  onCancel: () => void;
  error?: string;
  adsEnabled?: boolean;
}

export const ProcessingView: React.FC<ProcessingViewProps> = ({
  progress,
  stage,
  currentFrame,
  totalFrames,
  etaSeconds,
  status,
  onCancel,
  error,
  adsEnabled = true,
}) => {
  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-12">
      <div className="p-8 sm:p-12 rounded-2xl border border-slate-800 bg-slate-900/80 shadow-2xl relative overflow-hidden text-center">
        {/* Ambient background glow */}
        <div 
          className="absolute -top-24 -left-24 w-72 h-72 rounded-full pointer-events-none opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(59, 130, 246, 0.8) 0%, transparent 70%)',
            filter: 'blur(50px)',
          }}
          aria-hidden="true"
        />

        {error ? (
          <div>
            <div className="w-14 h-14 rounded-2xl bg-red-950/50 border border-red-800/80 text-red-400 mx-auto flex items-center justify-center mb-4">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2 font-display">
              Processing Interrupted
            </h3>
            <p className="text-sm text-slate-400 mb-6 max-w-md mx-auto">
              {error}
            </p>
            <button
              onClick={onCancel}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              Try Another Video
            </button>
          </div>
        ) : (
          <div>
            {/* Animated Neural Core Graphic */}
            <div className="relative w-20 h-20 mx-auto mb-6">
              <div className="absolute inset-0 rounded-full border border-blue-500/20 animate-ping opacity-75" />
              <div className="absolute inset-0 rounded-full border border-blue-500/40 animate-pulse" />
              <div className="w-full h-full rounded-2xl bg-blue-950/40 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-inner">
                <Cpu className="w-9 h-9 animate-pulse" />
              </div>
            </div>

            {/* Stage Title */}
            <div className="flex items-center justify-center gap-2 text-xs font-semibold text-blue-400 mb-2 uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
              <span>AI Engine Active · {status.toUpperCase()}</span>
            </div>

            <h3 className="text-2xl font-bold text-white mb-3 font-display">
              {stage || 'Processing Video Stream...'}
            </h3>

            {/* Progress Bar */}
            <div className="max-w-md mx-auto mb-4">
              <div className="w-full bg-slate-800/90 rounded-full h-3 overflow-hidden p-0.5 border border-slate-700/50">
                <div
                  className="bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-400 h-full rounded-full transition-all duration-300 shadow-sm"
                  style={{ width: `${Math.max(5, progress)}%` }}
                />
              </div>
            </div>

            {/* Telemetry row */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-400 font-mono mb-8">
              <span>{Math.round(progress)}% Completed</span>
              {currentFrame !== undefined && totalFrames !== undefined && (
                <>
                  <span className="text-slate-700">·</span>
                  <span>Frame {currentFrame.toLocaleString()} / {totalFrames.toLocaleString()}</span>
                </>
              )}
              {etaSeconds !== undefined && etaSeconds > 0 && (
                <>
                  <span className="text-slate-700">·</span>
                  <span>Estimated remaining: ~{etaSeconds}s</span>
                </>
              )}
            </div>

            {/* Processing Checklist */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left max-w-lg mx-auto mb-8 text-[11px]">
              <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/40">
                <div className="text-slate-400 mb-0.5">Denoise</div>
                <div className={`font-semibold ${progress >= 25 ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {progress >= 25 ? '✓ Finished' : 'In progress'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/40">
                <div className="text-slate-400 mb-0.5">Upscale</div>
                <div className={`font-semibold ${progress >= 50 ? 'text-emerald-400' : progress >= 25 ? 'text-blue-400' : 'text-slate-500'}`}>
                  {progress >= 50 ? '✓ Complete' : progress >= 25 ? 'Upscaling' : 'Queued'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/40">
                <div className="text-slate-400 mb-0.5">Edge Detail</div>
                <div className={`font-semibold ${progress >= 75 ? 'text-emerald-400' : progress >= 50 ? 'text-blue-400' : 'text-slate-500'}`}>
                  {progress >= 75 ? '✓ Restored' : progress >= 50 ? 'Synthesizing' : 'Queued'}
                </div>
              </div>

              <div className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/40">
                <div className="text-slate-400 mb-0.5">Audio & Mux</div>
                <div className={`font-semibold ${progress >= 95 ? 'text-emerald-400' : progress >= 75 ? 'text-blue-400' : 'text-slate-500'}`}>
                  {progress >= 95 ? '✓ Preserved' : progress >= 75 ? 'Encoding' : 'Queued'}
                </div>
              </div>
            </div>

            {/* Cancel Button */}
            <div>
              <button
                onClick={onCancel}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 rounded-lg border border-slate-700/60 transition-colors cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Cancel Processing</span>
              </button>
            </div>
          </div>
        )}

        {/* Section 19 Compliant Google Ad Slot */}
        {adsEnabled && (
          <div className="mt-8 pt-6 border-t border-slate-800 text-center">
            <div className="text-[10px] tracking-widest text-slate-400 uppercase mb-2">
              Advertisement
            </div>
            <div className="w-full max-w-xl mx-auto h-24 rounded-xl border border-slate-800/80 bg-slate-950/60 flex flex-col items-center justify-center p-3 text-slate-500">
              <span className="text-xs font-medium text-slate-400">Google AdSense Partner Placement</span>
              <span className="text-[11px] text-slate-400">Support free unlimited AI enhancement with verified sponsor placement</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
