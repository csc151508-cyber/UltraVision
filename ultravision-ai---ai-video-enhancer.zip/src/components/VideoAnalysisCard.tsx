import React, { useState } from 'react';
import { 
  Sparkles, 
  Layers, 
  Sliders, 
  Volume2, 
  Maximize2, 
  Check, 
  ArrowRight, 
  RotateCcw,
  Zap,
  ShieldCheck,
  Video
} from 'lucide-react';
import type { 
  VideoMetadata, 
  VideoAnalysis, 
  EnhancementMode, 
  OutputResolution, 
  EnhanceOptions 
} from '../types/index.ts';

interface VideoAnalysisCardProps {
  metadata: VideoMetadata;
  analysis: VideoAnalysis;
  originalUrl?: string;
  thumbnailUrl?: string;
  onEnhance: (options: EnhanceOptions) => void;
  onReset: () => void;
  isStarting: boolean;
}

export const VideoAnalysisCard: React.FC<VideoAnalysisCardProps> = ({
  metadata,
  analysis,
  originalUrl,
  thumbnailUrl,
  onEnhance,
  onReset,
  isStarting,
}) => {
  const [selectedMode, setSelectedMode] = useState<EnhancementMode>(analysis.recommendedMode || 'auto');
  const [selectedResolution, setSelectedResolution] = useState<OutputResolution>(analysis.recommendedResolution || '1080p');
  const [denoiseStrength, setDenoiseStrength] = useState<number>(60);
  const [faceRestoration, setFaceRestoration] = useState<boolean>(true);
  const [audioPreservation, setAudioPreservation] = useState<boolean>(metadata.hasAudio);

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${Math.round(bytes / 1024)} KB`;
  };

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const handleStartEnhance = () => {
    onEnhance({
      mode: selectedMode,
      targetResolution: selectedResolution,
      denoiseStrength,
      faceRestoration,
      audioPreservation,
    });
  };

  const modes: { id: EnhancementMode; title: string; desc: string; icon: string }[] = [
    {
      id: 'auto',
      title: 'Auto Enhance',
      desc: 'Optimized multi-pass pipeline balancing noise reduction and edge clarity.',
      icon: '✦',
    },
    {
      id: 'quality_boost',
      title: 'Quality Boost',
      desc: 'Aggressive compression artifact removal and spatial de-noising.',
      icon: '◈',
    },
    {
      id: 'face_enhance',
      title: 'Face Enhance',
      desc: 'Restores facial texture, eyelashes, and natural skin tones.',
      icon: '◉',
    },
    {
      id: 'ultra_hd',
      title: 'Ultra HD',
      desc: 'Deep sub-pixel super-resolution upscaling for maximum definition.',
      icon: '▲',
    },
  ];

  const resolutions: { id: OutputResolution; label: string; desc: string }[] = [
    { id: 'original', label: 'Original', desc: `${metadata.width}×${metadata.height}` },
    { id: '720p', label: '720p HD', desc: '1280×720' },
    { id: '1080p', label: '1080p FHD', desc: '1920×1080 (Recommended)' },
    { id: '1440p', label: '1440p 2K', desc: '2560×1440' },
    { id: '4k', label: '4K UHD', desc: '3840×2160' },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      {/* Top Banner */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>VIDEO READY FOR ENHANCEMENT</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
            Video Analysis & Settings
          </h2>
        </div>

        <button
          onClick={onReset}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-900 hover:bg-slate-800 rounded-lg border border-slate-800 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Upload Another</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Video Preview & Source Specs */}
        <div className="lg:col-span-5 space-y-6">
          {/* Player or Thumbnail Preview */}
          <div className="relative rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-xl aspect-video flex items-center justify-center group">
            {originalUrl ? (
              <video
                src={originalUrl}
                controls
                playsInline
                className="w-full h-full object-contain"
                poster={thumbnailUrl}
              />
            ) : thumbnailUrl ? (
              <img
                src={thumbnailUrl}
                alt="Source preview"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-slate-500">
                <Video className="w-10 h-10 mb-2 opacity-50" />
                <span className="text-xs">Preview Ready</span>
              </div>
            )}
          </div>

          {/* Unboxed Source File Metadata */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/60">
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
              Source Stream Telemetry
            </h3>

            <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-xs">
              <div>
                <span className="text-slate-500 block">Filename</span>
                <span className="text-slate-200 font-medium truncate block" title={metadata.filename}>
                  {metadata.filename}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Resolution</span>
                <span className="text-slate-200 font-mono font-medium">
                  {metadata.width} × {metadata.height} ({analysis.resolutionLabel})
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Frame Rate</span>
                <span className="text-slate-200 font-mono font-medium">
                  {metadata.fps} FPS
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Duration</span>
                <span className="text-slate-200 font-mono font-medium">
                  {formatDuration(metadata.duration)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">File Size</span>
                <span className="text-slate-200 font-mono font-medium">
                  {formatFileSize(metadata.filesize)}
                </span>
              </div>

              <div>
                <span className="text-slate-500 block">Audio Track</span>
                <span className="text-slate-200 font-medium flex items-center gap-1">
                  {metadata.hasAudio ? (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>{metadata.audioCodec || 'AAC'} preserved</span>
                    </>
                  ) : (
                    <span className="text-slate-500">No Audio</span>
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* AI Quality Analysis Card (Section 10 of Spec) */}
          <div className="p-5 rounded-xl border border-blue-950/60 bg-blue-950/20">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
                AI Quality Analysis
              </span>
              <span className="text-[11px] font-mono text-blue-300">
                Rec: {analysis.recommendedMode.replace('_', ' ').toUpperCase()}
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-blue-900/30">
                <span className="text-slate-400">Sensor Noise</span>
                <span className={`font-semibold ${
                  analysis.noiseLevel === 'High' ? 'text-amber-400' : analysis.noiseLevel === 'Medium' ? 'text-blue-300' : 'text-emerald-400'
                }`}>
                  {analysis.noiseLevel}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-blue-900/30">
                <span className="text-slate-400">Compression Artifacts</span>
                <span className={`font-semibold ${
                  analysis.compressionArtifacts === 'Heavy' ? 'text-amber-400' : 'text-blue-300'
                }`}>
                  {analysis.compressionArtifacts}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-blue-900/30">
                <span className="text-slate-400">Native Edge Detail</span>
                <span className={`font-semibold ${
                  analysis.detailClarity === 'Degraded' ? 'text-amber-400' : 'text-blue-300'
                }`}>
                  {analysis.detailClarity}
                </span>
              </div>

              <div className="flex justify-between items-center pt-1">
                <span className="text-slate-400">Estimated Process Time</span>
                <span className="text-slate-200 font-mono">
                  ~{analysis.estimatedProcessingSeconds}s
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Configurable Enhancement Pipeline */}
        <div className="lg:col-span-7 space-y-6">
          {/* Enhancement Mode Picker */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-3">
              1. Select AI Enhancement Mode
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {modes.map((m) => {
                const isSelected = selectedMode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMode(m.id)}
                    className={`p-4 rounded-xl text-left border transition-all cursor-pointer relative ${
                      isSelected
                        ? 'border-blue-500 bg-blue-950/40 shadow-sm shadow-blue-500/10'
                        : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                        <span className="text-blue-400 font-mono">{m.icon}</span>
                        <span>{m.title}</span>
                      </span>
                      {isSelected && (
                        <div className="w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      {m.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Output Resolution Picker */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-3">
              2. Target Output Resolution
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {resolutions.map((r) => {
                const isSelected = selectedResolution === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => setSelectedResolution(r.id)}
                    className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-blue-500 bg-blue-950/40'
                        : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="text-xs font-semibold text-white mb-0.5">
                      {r.label}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {r.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Advanced Pipeline Tuning */}
          <div className="p-5 rounded-xl border border-slate-800 bg-slate-900/50 space-y-4">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              3. Fine-Tuning & Audio
            </h4>

            {/* Denoise slider */}
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-400">Neural Denoise & Smoothing</span>
                <span className="text-slate-200 font-mono font-medium">{denoiseStrength}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={denoiseStrength}
                onChange={(e) => setDenoiseStrength(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            {/* Checkbox Options */}
            <div className="pt-2 border-t border-slate-800 space-y-2.5">
              <label className="flex items-center gap-3 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={audioPreservation}
                  onChange={(e) => setAudioPreservation(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
                <span>Preserve original audio track without loss</span>
              </label>

              <label className="flex items-center gap-3 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={faceRestoration}
                  onChange={(e) => setFaceRestoration(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
                <span>Enable neural facial feature & pupil reconstruction</span>
              </label>
            </div>
          </div>

          {/* Primary Action Button */}
          <div className="pt-2">
            <button
              onClick={handleStartEnhance}
              disabled={isStarting}
              className="w-full py-4 px-6 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-50 rounded-xl shadow-lg shadow-blue-500/25 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isStarting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Submitting to GPU Pipeline...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Enhance Video ({selectedResolution.toUpperCase()})</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
            <div className="text-center mt-2.5 text-[11px] text-slate-500">
              Zero watermarks · No sign-up required · Free online enhancement
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
