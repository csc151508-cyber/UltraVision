import React from 'react';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
  onOpenContact: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPrivacy,
  onOpenTerms,
  onOpenContact,
  onOpenAdmin,
}) => {
  return (
    <footer className="w-full border-t border-slate-800 bg-[#070a10] py-12 text-xs text-slate-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <span className="font-display font-semibold text-white tracking-tight">
              UltraVision AI
            </span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-slate-400">
            <button onClick={onOpenPrivacy} className="hover:text-white transition-colors cursor-pointer">
              Privacy Policy
            </button>
            <button onClick={onOpenTerms} className="hover:text-white transition-colors cursor-pointer">
              Terms of Service
            </button>
            <button onClick={onOpenContact} className="hover:text-white transition-colors cursor-pointer">
              Support & Contact
            </button>
            <button onClick={onOpenAdmin} className="hover:text-white transition-colors cursor-pointer">
              System Console
            </button>
          </div>
        </div>

        {/* Bottom copyright and ephemeral storage notice */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <p>
            © {new Date().getFullYear()} UltraVision AI. Next-generation neural video enhancement architecture.
          </p>
          <div className="flex items-center gap-2 text-slate-400">
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span>Ephemeral storage: All videos automatically purged after 6 hours</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
