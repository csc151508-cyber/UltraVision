import React, { useState, useEffect } from 'react';
import { 
  X, 
  Cpu, 
  Database, 
  Activity, 
  ShieldCheck, 
  Settings, 
  RefreshCw, 
  Lock, 
  Check, 
  AlertCircle 
} from 'lucide-react';
import type { AdminStats, SystemSettings } from '../types/index.ts';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({ isOpen, onClose }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [password, setPassword] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<'metrics' | 'jobs' | 'settings'>('metrics');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [jobsList, setJobsList] = useState<any[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin' || password === 'ultravision') {
      setIsAuthenticated(true);
      setAuthError(null);
      fetchAdminData();
    } else {
      setAuthError('Invalid administrator credentials.');
    }
  };

  const fetchAdminData = async () => {
    setIsLoading(true);
    try {
      const [statsRes, jobsRes, settingsRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/jobs'),
        fetch('/api/admin/settings'),
      ]);

      const statsData = await statsRes.json();
      const jobsData = await jobsRes.json();
      const settingsData = await settingsRes.json();

      if (statsData.success) setStats(statsData.stats);
      if (jobsData.success) setJobsList(jobsData.jobs);
      if (settingsData.success) setSettings(settingsData.settings);
    } catch (err) {
      console.error('Failed to load admin telemetry', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryJob = async (token: string) => {
    try {
      await fetch(`/api/admin/jobs/${token}/retry`, { method: 'POST' });
      fetchAdminData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      fetchAdminData();
    }
  }, [isOpen, isAuthenticated]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col bg-[#0d121c] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-display">
                UltraVision AI Admin & Worker Console
              </h2>
              <span className="text-[11px] text-slate-400">
                GPU Worker Fleet & Queue Diagnostics
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        {!isAuthenticated ? (
          <div className="p-8 max-w-md mx-auto my-auto text-center w-full">
            <div className="w-12 h-12 rounded-xl bg-blue-950/60 border border-blue-800/80 text-blue-400 flex items-center justify-center mx-auto mb-4">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 font-display">
              Administrator Authentication
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              Enter admin master password to inspect pipeline telemetry and modify retention policies.
            </p>

            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="password"
                placeholder="Enter password (e.g. admin)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-none focus:border-blue-500"
                autoFocus
              />
              {authError && (
                <div className="text-xs text-red-400 flex items-center gap-1.5 justify-center">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{authError}</span>
                </div>
              )}
              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-md transition-colors cursor-pointer"
              >
                Sign In to Console
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Top Navigation Tabs */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
                <button
                  onClick={() => setActiveTab('metrics')}
                  className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                    activeTab === 'metrics' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  System Metrics
                </button>
                <button
                  onClick={() => setActiveTab('jobs')}
                  className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                    activeTab === 'jobs' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Job Queue ({jobsList.length})
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                    activeTab === 'settings' ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Settings & Limits
                </button>
              </div>

              <button
                onClick={fetchAdminData}
                disabled={isLoading}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {/* Tab 1: System Metrics & Worker Telemetry */}
            {activeTab === 'metrics' && stats && (
              <div className="space-y-6">
                {/* Worker Status Banner */}
                <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                    <div>
                      <div className="text-xs font-semibold text-white">GPU Worker #1: NVIDIA L40S Cluster</div>
                      <div className="text-[11px] text-slate-400">Worker status: {stats.workerStatus} · Driver: CUDA 12.4 · PyTorch 2.4</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-xs font-mono">
                    <span className="text-slate-400">GPU Util: <strong className="text-blue-400">{stats.gpuUtilization}%</strong></span>
                    <span className="text-slate-400">VRAM: <strong className="text-purple-400">{stats.vramUsageGB} / {stats.vramTotalGB} GB</strong></span>
                  </div>
                </div>

                {/* Stat Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
                    <div className="text-xs text-slate-400 mb-1">Total Jobs</div>
                    <div className="text-2xl font-bold font-mono text-white">{stats.totalJobs}</div>
                    <div className="text-[11px] text-emerald-400 mt-1">+{stats.todayJobs} today</div>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
                    <div className="text-xs text-slate-400 mb-1">Active / Queued</div>
                    <div className="text-2xl font-bold font-mono text-blue-400">{stats.processingJobs}</div>
                    <div className="text-[11px] text-slate-400 mt-1">In worker pipeline</div>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
                    <div className="text-xs text-slate-400 mb-1">Total Storage</div>
                    <div className="text-2xl font-bold font-mono text-purple-400">{stats.totalStorageMB} MB</div>
                    <div className="text-[11px] text-slate-400 mt-1">6h auto-cleanup enabled</div>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40">
                    <div className="text-xs text-slate-400 mb-1">Avg Processing</div>
                    <div className="text-2xl font-bold font-mono text-emerald-400">{stats.averageProcessingTimeSec}s</div>
                    <div className="text-[11px] text-slate-400 mt-1">97.3% success rate</div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Job Queue List */}
            {activeTab === 'jobs' && (
              <div className="space-y-4">
                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/40">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/80">
                        <th className="p-3 font-semibold">JOB TOKEN</th>
                        <th className="p-3 font-semibold">STATUS</th>
                        <th className="p-3 font-semibold">FILE / RES</th>
                        <th className="p-3 font-semibold">OUTPUT</th>
                        <th className="p-3 font-semibold text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-mono">
                      {jobsList.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-6 text-center text-slate-500 font-sans">
                            No active jobs in local session. Upload a video to see real-time pipeline execution.
                          </td>
                        </tr>
                      ) : (
                        jobsList.map((j) => (
                          <tr key={j.jobToken} className="hover:bg-slate-800/30">
                            <td className="p-3 text-slate-300 font-mono text-[11px] truncate max-w-[120px]">
                              {j.jobToken}
                            </td>
                            <td className="p-3">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                                j.status === 'completed'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : j.status === 'failed'
                                  ? 'bg-red-950 text-red-300 border border-red-800'
                                  : 'bg-blue-950 text-blue-300 border border-blue-800 animate-pulse'
                              }`}>
                                {j.status}
                              </span>
                            </td>
                            <td className="p-3 text-slate-300 font-sans">
                              <div className="truncate max-w-[160px] font-medium">{j.filename}</div>
                              <div className="text-[10px] text-slate-500 font-mono">{j.resolution} · {j.duration}s</div>
                            </td>
                            <td className="p-3 text-slate-400">
                              {j.outputResolution}
                            </td>
                            <td className="p-3 text-right">
                              {j.status === 'failed' && (
                                <button
                                  onClick={() => handleRetryJob(j.jobToken)}
                                  className="px-2.5 py-1 text-[11px] font-sans bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors cursor-pointer"
                                >
                                  Retry
                                </button>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 3: System Settings & Config */}
            {activeTab === 'settings' && settings && (
              <form onSubmit={handleSaveSettings} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-2">
                    <label className="text-xs font-semibold text-white block">
                      Max Upload Size (MB)
                    </label>
                    <input
                      type="number"
                      value={settings.maxUploadSizeMB}
                      onChange={(e) => setSettings({ ...settings, maxUploadSizeMB: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white"
                    />
                    <span className="text-[10px] text-slate-500 block">Default 500 MB</span>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-2">
                    <label className="text-xs font-semibold text-white block">
                      Max Video Duration (Seconds)
                    </label>
                    <input
                      type="number"
                      value={settings.maxDurationSec}
                      onChange={(e) => setSettings({ ...settings, maxDurationSec: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white"
                    />
                    <span className="text-[10px] text-slate-500 block">300s = 5 minutes maximum</span>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-2">
                    <label className="text-xs font-semibold text-white block">
                      Automatic Storage Retention (Hours)
                    </label>
                    <input
                      type="number"
                      value={settings.retentionHours}
                      onChange={(e) => setSettings({ ...settings, retentionHours: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white"
                    />
                    <span className="text-[10px] text-slate-500 block">Deletes original & output files permanently</span>
                  </div>

                  <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 space-y-3">
                    <label className="text-xs font-semibold text-white block">
                      Feature Toggles
                    </label>
                    <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.adsEnabled}
                        onChange={(e) => setSettings({ ...settings, adsEnabled: e.target.checked })}
                        className="rounded border-slate-700 bg-slate-800 text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                      />
                      <span>Google AdSense partner slots enabled</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.maintenanceMode}
                        onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                        className="rounded border-slate-700 bg-slate-800 text-amber-500 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                      />
                      <span>Maintenance Mode</span>
                    </label>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                  {saveSuccess && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5" />
                      <span>Settings updated successfully</span>
                    </span>
                  )}
                  <button
                    type="submit"
                    className="ml-auto px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors cursor-pointer"
                  >
                    Save Configuration
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
