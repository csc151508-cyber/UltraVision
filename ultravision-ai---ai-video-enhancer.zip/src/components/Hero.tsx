import React from 'react';
import { ArrowDown, Zap, Shield, Play } from 'lucide-react';

interface HeroProps {
  onScrollToUpload: () => void;
  onTrySample: (sampleId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToUpload, onTrySample }) => {
  return (
    <section className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden border-b border-slate-800/60">
      {/* Subtle ambient gradient mesh */}
      <div 
        className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 pointer-events-none opacity-25"
        style={{
          background: 'radial-gradient(circle at 50% 20%, rgba(59, 130, 246, 0.45) 0%, rgba(147, 51, 234, 0.15) 45%, transparent 70%)',
          filter: 'blur(70px)',
        }}
        aria-hidden="true"
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        {/* Unboxed editorial kicker */}
        <div className="flex items-center justify-center gap-2 text-xs font-medium text-slate-400 mb-4 tracking-wide uppercase">
          <span>AI Neural Restoration Engine</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Zero Sign-up Required</span>
        </div>

        {/* Display Headline */}
        <h1 
          className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white mb-6 font-display"
          style={{ textWrap: 'balance' }}
        >
          Your Video. Reimagined by AI.
        </h1>

        {/* Value Proposition */}
        <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto mb-8 font-normal leading-relaxed">
          Transform low-quality, blurry, and compressed videos into cleaner, sharper, and higher-resolution videos with automated AI-powered restoration.
        </p>

        {/* CTAs */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-10">
          <button
            onClick={onScrollToUpload}
            className="px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-xl shadow-lg shadow-blue-500/20 transition-all duration-200 inline-flex items-center gap-2 cursor-pointer"
          >
            <span>Upload Your Video</span>
            <ArrowDown className="w-4 h-4" />
          </button>

          <button
            onClick={() => onTrySample('sample_vintage_street')}
            className="px-5 py-3.5 text-sm font-medium text-slate-200 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all duration-150 inline-flex items-center gap-2 cursor-pointer hover:border-slate-600"
          >
            <Play className="w-4 h-4 text-blue-400 fill-blue-400" />
            <span>Test with Sample Clip</span>
          </button>
        </div>

        {/* Zero-Pill Unboxed Trust & Metadata */}
        <div className="flex flex-wrap items-center justify-center gap-y-2 gap-x-4 text-xs text-slate-400">
          <span>No account required</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Up to 4K upscaling</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Audio track preserved</span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Auto-deleted after 6 hours</span>
        </div>
      </div>
    </section>
  );
};
